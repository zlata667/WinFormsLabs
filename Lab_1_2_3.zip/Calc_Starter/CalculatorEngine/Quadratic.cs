﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Quadratic : Form
    {
        public Quadratic()
        {
            InitializeComponent();
        }
        private async Task<string> Korni(int a, int b, int c)
        {
            double D;
            double x1, x2;
            D = Math.Pow(b, 2) - 4 * a * c;
            if (D > 0 || D == 0)
            {
                x1 = (-b + Math.Sqrt(D)) / (2 * a);
                x2 = (-b - Math.Sqrt(D)) / (2 * a);
                string result = String.Format("x1 = {0} \n x2 = {1}", x1, x2);
                return await Task.Run(() =>
                {
                    return result;
                });
            }
            else
            {
                return await Task.Run(() =>
                {
                    return ("Действительных корней нет");
                });
            }
        }
        
        private async void button1_Click(object sender, EventArgs e)
        {

            int a, b, c;
            try
            {
                a = Int32.Parse(textBox1.Text);
                b = Int32.Parse(textBox2.Text);
                c = Int32.Parse(textBox3.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("При выполнении преобразования типов возникла ошибка");
                textBox3.Text = textBox2.Text = textBox1.Text = "";
                return;
            }
            label5.Text = await Korni(a,b,c);
        }
    }
}
