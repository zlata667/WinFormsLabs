﻿using System;
using System.Collections.Generic;

namespace ValidatingForm
{
    class User
    {
        private string Name { get; set; }
        private string Surname { get; set; }
        private int Age { get; set; }
        private int Pin { get; set; }

        public User(string name, string surname, int age, int pin)
        {
            this.Name = name;
            this.Surname = surname;
            this.Age = age;
            this.Pin = pin;
        }
        public override string ToString()
        {

            return "\nПользователь:\n Имя: " + Name + "\n Фамилия: " + Surname + "\n Годиков: " + Age + "\n ПИН: " + Pin;
        }
    }
}
