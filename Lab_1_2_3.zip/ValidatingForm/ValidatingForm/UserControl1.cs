﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ValidatingForm
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }
        public string Name 
        {
            get { return textBox1.Text; }
            set { textBox1.Text = value; }
        }
        public string Surname 
        {
            get { return textBox1.Text; }
            set { textBox1.Text = value; }
        }
        public string Age 
        {
            get { return textBox3.Text; }
            set { textBox3.Text = value; }
        }
        public string Pin
        {
            get { return textBox4.Text; }
            set { textBox4.Text = value; }
        }
        
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Поле Name не может содержать цифры");
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Поле Surname не может содержать цифры");
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Поле Age не может содержать буквы");
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Поле PIN не может содержать буквы");
            }
        }
        List<User> users = new List<User>();
        private void button1_Click_1(object sender, EventArgs e)
        {
            User u = new User(Name, Surname, int.Parse(Age), int.Parse(Pin));
            users.Add(u);
            StringBuilder sb = new StringBuilder();
            foreach (User item in users)
            {
                sb.Append("\n" + item.ToString());
            }
            richTextBox1.Text = sb.ToString();
        }
    }
}
