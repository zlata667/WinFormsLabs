﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Controlnoe7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private async Task<string> GoButt(int maxValue)
        {
            System.Text.StringBuilder resultText = new
            System.Text.StringBuilder();
            for (int trial = 2; trial <= maxValue; trial++)
            {
                bool isPrime = true;
                for (int divisor = 2; divisor <= Math.Sqrt(trial); divisor++)
                {
                    if (trial % divisor == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }
                if (isPrime)
                {
                    resultText.AppendFormat("{0} ", trial);
                }
            }
            string result = resultText.ToString();
            return await Task.Run(() =>
            {
                return result;
            }
            );
        }
        private async void button1_Click(object sender, EventArgs e)
        {
            int maxValue;
            try
            {
                maxValue = Int32.Parse(textBox1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("При выполнении преобразования типов возникла ошибка");
                textBox1.Text = "";
                return;
            }
            string res = await GoButt(maxValue);
            label2.Text = res.ToString();
        }
    }
}
